﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace project_visual
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            Visible = false;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            Visible = false;

            string connectionString = "Data Source=localhost;Initial Catalog=daftarform;User ID=root;Password=";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {

                string userId = textBox1.Text;
                string query = $"SELECT  * FROM akun_daftar WHERE Username = '{userId}'";
                connection.Open();

                MySqlCommand command = new MySqlCommand(query, connection);

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string username = reader.GetString("Username");
                        string password = reader.GetString("Password");

                        if (username != null && password != null)
                        {
                            if (password == textBox2.Text)
                            {
                                MessageBox.Show("login berhasil");
                            }
                            else
                            {
                                MessageBox.Show("login gagal");
                            }
                        }
                    }
                }

            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}

