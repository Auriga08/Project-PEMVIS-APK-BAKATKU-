﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
 
    public partial class Form12 : Form
    {
        public int nilai = 0;
        public Form12(int poin)
        {
            InitializeComponent();
            nilai = poin;
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4(nilai);
            f4.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nilai = nilai + 10;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            nilai = nilai + 5;
        }
    }
}
