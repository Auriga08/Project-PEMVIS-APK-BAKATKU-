﻿namespace project_visual
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label2 = new Label();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            label3 = new Label();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            label4 = new Label();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            label5 = new Label();
            radioButton9 = new RadioButton();
            radioButton10 = new RadioButton();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.RosyBrown;
            label1.Font = new Font("Perpetua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(129, 19);
            label1.Name = "label1";
            label1.Size = new Size(235, 27);
            label1.TabIndex = 1;
            label1.Text = "6. Kamu lebih suka bekerja";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton1.Location = new Point(139, 49);
            radioButton1.Margin = new Padding(2, 3, 2, 3);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(232, 21);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "Sesuai jadwal yang sudah direncanakan";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton2.Location = new Point(139, 76);
            radioButton2.Margin = new Padding(2, 3, 2, 3);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(169, 21);
            radioButton2.TabIndex = 10;
            radioButton2.TabStop = true;
            radioButton2.Text = "Sesuai mood dan kemauan";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.RosyBrown;
            label2.Font = new Font("Perpetua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(129, 110);
            label2.Name = "label2";
            label2.Size = new Size(291, 27);
            label2.TabIndex = 11;
            label2.Text = "7. Di sebuah acara, kamu biasanya";
            label2.Click += label2_Click;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton3.Location = new Point(139, 140);
            radioButton3.Margin = new Padding(2, 3, 2, 3);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(226, 21);
            radioButton3.TabIndex = 12;
            radioButton3.TabStop = true;
            radioButton3.Text = "Semangat ikut acaranya sampai selesai";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton4.Location = new Point(139, 167);
            radioButton4.Margin = new Padding(2, 3, 2, 3);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(263, 21);
            radioButton4.TabIndex = 13;
            radioButton4.TabStop = true;
            radioButton4.Text = "Pulang cepat karena kamu lelah berinteraksi";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.RosyBrown;
            label3.Font = new Font("Perpetua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(129, 201);
            label3.Name = "label3";
            label3.Size = new Size(259, 27);
            label3.TabIndex = 14;
            label3.Text = "8. Kamu lebih tertarik kepada";
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton5.Location = new Point(139, 231);
            radioButton5.Margin = new Padding(2, 3, 2, 3);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(190, 21);
            radioButton5.TabIndex = 15;
            radioButton5.TabStop = true;
            radioButton5.Text = "Orang yang logis dan praktikal";
            radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton6.Location = new Point(139, 258);
            radioButton6.Margin = new Padding(2, 3, 2, 3);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(141, 21);
            radioButton6.TabIndex = 16;
            radioButton6.TabStop = true;
            radioButton6.Text = "Orang yang imajinatif";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.RosyBrown;
            label4.Font = new Font("Perpetua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(129, 293);
            label4.Name = "label4";
            label4.Size = new Size(259, 27);
            label4.TabIndex = 17;
            label4.Text = "9. Kamu lebih tertarik kepada";
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton7.Location = new Point(139, 323);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(165, 21);
            radioButton7.TabIndex = 18;
            radioButton7.TabStop = true;
            radioButton7.Text = "Kenyataan atau apa adanya";
            radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton8.Location = new Point(139, 350);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(336, 21);
            radioButton8.TabIndex = 19;
            radioButton8.TabStop = true;
            radioButton8.Text = "Kemungkinan atau apa yang mungkin terjadi dimasa depan";
            radioButton8.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.RosyBrown;
            label5.Font = new Font("Perpetua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(129, 386);
            label5.Name = "label5";
            label5.Size = new Size(272, 27);
            label5.TabIndex = 20;
            label5.Text = "10. Kamu orangnya cenderung";
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton9.Location = new Point(139, 416);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(95, 21);
            radioButton9.TabIndex = 21;
            radioButton9.TabStop = true;
            radioButton9.Text = "Tepat waktu";
            radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton10.Location = new Point(139, 443);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(59, 21);
            radioButton10.TabIndex = 22;
            radioButton10.TabStop = true;
            radioButton10.Text = "Santai";
            radioButton10.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = Color.WhiteSmoke;
            button1.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(639, 450);
            button1.Name = "button1";
            button1.Size = new Size(140, 36);
            button1.TabIndex = 23;
            button1.Text = "LIHAT HASIL";
            button1.UseVisualStyleBackColor = false;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.RosyBrown;
            ClientSize = new Size(800, 504);
            Controls.Add(button1);
            Controls.Add(radioButton10);
            Controls.Add(radioButton9);
            Controls.Add(label5);
            Controls.Add(radioButton8);
            Controls.Add(radioButton7);
            Controls.Add(label4);
            Controls.Add(radioButton6);
            Controls.Add(radioButton5);
            Controls.Add(label3);
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(label2);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label1);
            Name = "Form5";
            Text = "Form5";
            Load += Form5_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private Label label3;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private Label label4;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private Label label5;
        private RadioButton radioButton9;
        private RadioButton radioButton10;
        private Button button1;
    }
}