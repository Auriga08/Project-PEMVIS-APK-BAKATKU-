﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
    public partial class Form15 : Form
    {
        public int nilai = 0;
        public Form15(int poin)
        {
            InitializeComponent();
            nilai = poin;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form16 f16 = new Form16(nilai);
            f16.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nilai = nilai + 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            nilai = nilai + 10;
        }
    }
}
