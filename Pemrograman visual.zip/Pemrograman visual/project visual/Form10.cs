﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
    public partial class Form10 : Form
    {
        public int nilai = 0;
        public Form10(int poin)
        {
            InitializeComponent();
            nilai = poin;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form11 f11 = new Form11(nilai);
            f11.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nilai = nilai + 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            nilai = nilai + 10;
        }
    }
}
