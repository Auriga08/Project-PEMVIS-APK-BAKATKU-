﻿namespace project_visual
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label6 = new Label();
            label5 = new Label();
            textBox5 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            button2 = new Button();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.BackgroundImageLayout = ImageLayout.Stretch;
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(82, 55);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(629, 385);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.RosyBrown;
            label6.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(37, 308);
            label6.Name = "label6";
            label6.Size = new Size(77, 21);
            label6.TabIndex = 12;
            label6.Text = "Password:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.RosyBrown;
            label5.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(37, 252);
            label5.Name = "label5";
            label5.Size = new Size(81, 21);
            label5.TabIndex = 11;
            label5.Text = "Username:";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.RosyBrown;
            textBox5.Location = new Point(143, 304);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(307, 27);
            textBox5.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.RosyBrown;
            label4.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(37, 198);
            label4.Name = "label4";
            label4.Size = new Size(52, 21);
            label4.TabIndex = 9;
            label4.Text = "Email:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.RosyBrown;
            label3.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(37, 138);
            label3.Name = "label3";
            label3.Size = new Size(100, 21);
            label3.TabIndex = 8;
            label3.Text = "Tanggal lahir:";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.RosyBrown;
            label2.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(37, 79);
            label2.Name = "label2";
            label2.Size = new Size(54, 21);
            label2.TabIndex = 7;
            label2.Text = "Nama:";
            label2.Click += label2_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.RosyBrown;
            button2.Font = new Font("Perpetua", 6F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(265, 337);
            button2.Name = "button2";
            button2.Size = new Size(84, 31);
            button2.TabIndex = 6;
            button2.Text = "Sign In";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.RosyBrown;
            textBox4.Location = new Point(143, 248);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(307, 27);
            textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.RosyBrown;
            textBox3.Location = new Point(143, 194);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(307, 27);
            textBox3.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.RosyBrown;
            textBox2.Location = new Point(143, 134);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(307, 27);
            textBox2.TabIndex = 3;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.RosyBrown;
            textBox1.Location = new Point(143, 75);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(307, 27);
            textBox1.TabIndex = 2;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.RosyBrown;
            label1.Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(265, 23);
            label1.Name = "label1";
            label1.Size = new Size(77, 17);
            label1.TabIndex = 1;
            label1.Text = "Form Sign In";
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 500);
            Controls.Add(groupBox1);
            Name = "Form7";
            Text = "Form7";
            Load += Form7_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button2;
        private TextBox textBox5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label6;
        private Label label5;
        private TextBox textBox4;
    }
}