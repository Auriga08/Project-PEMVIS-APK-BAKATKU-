﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
    public partial class Form9 : Form
    {
        public int nilai = 0;

        public int nilai2 = 0;
        public Form9(int poin)
        {
            InitializeComponent();
            nilai = poin;
            nilai2 = poin;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           

            if (nilai >= nilai2 + 10)
            {
                nilai = nilai + 0;
            }
            else
            {
                nilai = nilai + 10;
            }




        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form10 f10 = new Form10(nilai);
            f10.Show();
            Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (nilai >= nilai2 + 5)
            {
                nilai = nilai + 0;
            }
            else
            {

                nilai = nilai + 5;
            }

            


        }
    }
}
