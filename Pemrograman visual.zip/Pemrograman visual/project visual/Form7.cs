﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace project_visual
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Form2 f2 = new Form2();
            //f2.Show();
            //Visible = false;


            string nama = textBox1.Text;
            string tanggal_lahir = textBox2.Text;
            string email = textBox3.Text;
            string username = textBox4.Text;
            string pw = textBox5.Text;


            string connectionString = "Data Source=localhost;Initial Catalog=daftarform;User ID=root;Password=";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {

                string query = "INSERT INTO akun_daftar (Nama,Tanggal_lahir,Email,Username,Password) VALUES (@nama,@tanggal_lahir,@email,@username,@pw)";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@nama", nama);
                command.Parameters.AddWithValue("@tanggal_lahir", tanggal_lahir);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@pw", pw);

                connection.Open();

                int result = command.ExecuteNonQuery();

                if (result < 0)
                    MessageBox.Show("Error inserting data into Database!");
                else
                    MessageBox.Show("pendaftaran berhasil");
                this.Hide();
                Form6 form6 = new Form6();
                form6.ShowDialog();

                try
                {

                  
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection failed: " + ex.Message);
                }
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
