﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
    public partial class Form11 : Form
    {
        public int nilai = 0;
        public Form11(int poin)
        {
            InitializeComponent();
            nilai = poin;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nilai = nilai + 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form12 f12 = new Form12(nilai);
            f12.Show();
            Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
           nilai = nilai + 5;
        }
    }
}
