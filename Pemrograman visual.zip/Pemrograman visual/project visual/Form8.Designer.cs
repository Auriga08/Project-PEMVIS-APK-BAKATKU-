﻿namespace project_visual
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button3 = new Button();
            button1 = new Button();
            button4 = new Button();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = Color.WhiteSmoke;
            button2.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.Location = new Point(209, 164);
            button2.Name = "button2";
            button2.Size = new Size(356, 30);
            button2.TabIndex = 22;
            button2.Text = "Hanya bertegur sapa pada orang yang sudah dikenal                    ";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.WhiteSmoke;
            button3.ImageAlign = ContentAlignment.MiddleRight;
            button3.Location = new Point(209, 200);
            button3.Name = "button3";
            button3.Size = new Size(356, 42);
            button3.TabIndex = 23;
            button3.Text = "Berbaur dengan banyak orang termasuk orang yang baru dikenal";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MistyRose;
            button1.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(318, 305);
            button1.Margin = new Padding(2, 3, 2, 3);
            button1.Name = "button1";
            button1.Size = new Size(139, 38);
            button1.TabIndex = 24;
            button1.Text = "SELANJUTNYA";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.RosyBrown;
            button4.Location = new Point(130, 97);
            button4.Name = "button4";
            button4.Size = new Size(515, 45);
            button4.TabIndex = 25;
            button4.Text = "1. Ketika sedang di sebuah acara kamu biasanya?";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.RosyBrown;
            BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 479);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(button2);
            Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "Form8";
            Text = "Form8";
            Load += Form8_Load;
            ResumeLayout(false);
        }

        #endregion
        private Button button2;
        private Button button3;
        private Button button1;
        private Button button4;
    }
}