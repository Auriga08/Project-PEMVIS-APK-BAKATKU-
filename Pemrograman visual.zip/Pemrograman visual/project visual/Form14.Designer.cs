﻿namespace project_visual
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            button1 = new Button();
            button3 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // button4
            // 
            button4.BackColor = Color.RosyBrown;
            button4.Location = new Point(149, 105);
            button4.Name = "button4";
            button4.Size = new Size(503, 45);
            button4.TabIndex = 49;
            button4.Text = "8. Kamu lebih tertarik kepada";
            button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.MistyRose;
            button1.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(335, 304);
            button1.Margin = new Padding(2, 3, 2, 3);
            button1.Name = "button1";
            button1.Size = new Size(139, 49);
            button1.TabIndex = 48;
            button1.Text = "SELANJUTNYA";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.WhiteSmoke;
            button3.BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            button3.ImageAlign = ContentAlignment.MiddleRight;
            button3.Location = new Point(229, 200);
            button3.Name = "button3";
            button3.Size = new Size(357, 44);
            button3.TabIndex = 47;
            button3.Text = "Orang yang imajinatif";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.WhiteSmoke;
            button2.BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            button2.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.Location = new Point(229, 156);
            button2.Name = "button2";
            button2.Size = new Size(357, 38);
            button2.TabIndex = 46;
            button2.Text = "Orang yang logis dan praktikal";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Form14
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 481);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(button2);
            Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "Form14";
            Text = "Form14";
            ResumeLayout(false);
        }

        #endregion

        private Button button4;
        private Button button1;
        private Button button3;
        private Button button2;
    }
}