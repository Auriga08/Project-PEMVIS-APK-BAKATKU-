﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_visual
{
    public partial class Form16 : Form
    {
        public int nilai = 0;
        public Form16(int poin)
        {
            InitializeComponent();
            nilai = poin;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            nilai = nilai + 5;

            string poi = nilai.ToString();
            MessageBox.Show("poin yang terkumpul" + poi);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            nilai = nilai + 10;
            string poi = nilai.ToString();
            MessageBox.Show("poin yang terkumpul" + poi);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int poin
                = (int)nilai;
            if (poin >= 60 && poin <= 70)
            {
                // Jika poin dalam kisaran, tampilkan form
                Form20 form = new Form20();
                form.ShowDialog();
                Application.Run(form);
            }

            else if (poin >= 71 && poin <= 80)
            {
                Form17 form = new Form17();
                form.ShowDialog();
                Application.Run(form);



            }

            else if (poin >= 81 && poin <= 90)
            {
                Form18 form = new Form18();
                form.ShowDialog();
                Application.Run(form);



            }

            else if (poin >= 91 && poin <= 100)
            {
                Form19 form = new Form19();
                form.ShowDialog();
                Application.Run(form);



            }
            else
            {
                MessageBox.Show("Poin di luar rentang yang diharapkan.");
            }
        }
    }
}
