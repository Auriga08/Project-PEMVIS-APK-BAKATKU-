﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace project_visual
{
    public partial class Form8 : Form
    {

        public int poin = 0;
        public Form8()
        {
            InitializeComponent();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            if (poin == 10)
            {
                {
                    poin = poin - 10;
                }

                poin = 5;

             
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (poin == 5)
            {
                poin = poin - 5;
            }

            poin = 10;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 f9 = new Form9(poin);
            f9.Show();
            Visible = false;
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
