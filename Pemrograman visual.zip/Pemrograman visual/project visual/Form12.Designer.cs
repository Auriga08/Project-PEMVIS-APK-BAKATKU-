﻿namespace project_visual
{
    partial class Form12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            button1 = new Button();
            button3 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // button4
            // 
            button4.BackColor = Color.RosyBrown;
            button4.Location = new Point(149, 100);
            button4.Name = "button4";
            button4.Size = new Size(503, 42);
            button4.TabIndex = 41;
            button4.Text = "5. Kamu lebih tertarik pada sesuatu yang?";
            button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.MistyRose;
            button1.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(335, 308);
            button1.Margin = new Padding(2, 3, 2, 3);
            button1.Name = "button1";
            button1.Size = new Size(139, 43);
            button1.TabIndex = 40;
            button1.Text = "SELANJUTNYA";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.WhiteSmoke;
            button3.BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            button3.ImageAlign = ContentAlignment.MiddleRight;
            button3.Location = new Point(228, 194);
            button3.Name = "button3";
            button3.Size = new Size(357, 31);
            button3.TabIndex = 39;
            button3.Text = "Menyentuh perasaan";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.WhiteSmoke;
            button2.BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            button2.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.Location = new Point(228, 155);
            button2.Name = "button2";
            button2.Size = new Size(357, 33);
            button2.TabIndex = 38;
            button2.Text = "Menjanjikan";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Form12
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 489);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(button2);
            Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "Form12";
            Text = "Form12";
            Load += Form12_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button button4;
        private Button button1;
        private Button button3;
        private Button button2;
    }
}