﻿namespace project_visual
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label6 = new Label();
            label5 = new Label();
            button2 = new Button();
            label2 = new Label();
            button1 = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.BackgroundImageLayout = ImageLayout.Stretch;
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(98, 64);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(551, 333);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.RosyBrown;
            label6.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(30, 120);
            label6.Name = "label6";
            label6.Size = new Size(77, 21);
            label6.TabIndex = 13;
            label6.Text = "Password:";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.RosyBrown;
            label5.Font = new Font("Perpetua", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(62, 76);
            label5.Name = "label5";
            label5.Size = new Size(81, 21);
            label5.TabIndex = 12;
            label5.Text = "Username:";
            label5.Click += label5_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.RosyBrown;
            button2.Font = new Font("Perpetua", 6F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(400, 238);
            button2.Name = "button2";
            button2.Size = new Size(57, 21);
            button2.TabIndex = 5;
            button2.Text = "Sign In";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Perpetua", 6F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(210, 243);
            label2.Name = "label2";
            label2.Size = new Size(170, 11);
            label2.TabIndex = 4;
            label2.Text = "Jika belum punya akun, sign in terlebih dahulu";
            // 
            // button1
            // 
            button1.BackColor = Color.RosyBrown;
            button1.Location = new Point(242, 167);
            button1.Name = "button1";
            button1.Size = new Size(119, 46);
            button1.TabIndex = 3;
            button1.Text = "Log In";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.RosyBrown;
            textBox2.Location = new Point(150, 116);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(307, 25);
            textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.RosyBrown;
            textBox1.Location = new Point(178, 72);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(307, 25);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.RosyBrown;
            label1.Location = new Point(261, 21);
            label1.Name = "label1";
            label1.Size = new Size(76, 17);
            label1.TabIndex = 0;
            label1.Text = "Form Log In";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wp3469871_white_background_hd_wallpapers;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(801, 490);
            Controls.Add(groupBox1);
            Font = new Font("Perpetua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Form6";
            Text = "Form6";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Button button1;
        private TextBox textBox2;
        private Button button2;
        private Label label5;
        private Label label6;
    }
}