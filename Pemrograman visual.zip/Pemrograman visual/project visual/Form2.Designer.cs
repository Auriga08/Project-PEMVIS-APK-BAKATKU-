﻿namespace project_visual
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            label1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Perpetua", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 164);
            label1.Name = "label1";
            label1.Size = new Size(510, 160);
            label1.TabIndex = 0;
            label1.Text = "Kapabilitasku\r\n\r\nAdalah sebuah kerangka kerja penilaian \r\npotensi diri yang dirancang khusus untuk\r\nmenganalisis tipe kepribadian seseorang\r\n";
            // 
            // button1
            // 
            button1.BackColor = Color.RosyBrown;
            button1.Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(335, 381);
            button1.Name = "button1";
            button1.Size = new Size(125, 42);
            button1.TabIndex = 1;
            button1.Text = "MULAI";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 483);
            Controls.Add(button1);
            Controls.Add(label1);
            Font = new Font("Perpetua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
    }
}